// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>     // cout
#include <limits>       // numeric_limits
#include <type_traits>  // is_signed, is_integral
#include <typeinfo>     // typeid(T).name()
#include <cmath>        // isfinite

using namespace std; // omission of std:: prefixes 
/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start + (increment * steps)</returns>
// 
template <typename T>
bool add_numbers(T const& start, T const& increment, unsigned long int const& steps, T& out)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        if constexpr (numeric_limits<T>::is_integer) {
            // Integer path
            const T maxv = numeric_limits<T>::max();
            const T minv = numeric_limits<T>::lowest();

            if constexpr (is_signed<T>::value) {
                if (increment > 0 && result > maxv - increment) {
                    out = maxv;              // edit: clamp to +max
                    return false;            // edit: ding overflow
                }
                if (increment < 0 && result < minv - increment) {
                    out = minv;              // edit: clamp to -min
                    return false;            // edit: ding underflow
                }
            }
            else {
                // Unsigned: only possible issue is overflow when adding a positive increment
                if (result > maxv - increment) {
                    out = maxv;              // edit: clamp to max
                    return false;            // edit: ding overflow
                }
            }

            result = static_cast<T>(result + increment); // safe after checks
        }
        else {
            // Floating-point path
            long double tmp = static_cast<long double>(result) + static_cast<long double>(increment);
            const long double hi = static_cast<long double>(numeric_limits<T>::max());
            const long double lo = static_cast<long double>(numeric_limits<T>::lowest());

            if (!isfinite(tmp) || tmp > hi) {
                out = numeric_limits<T>::max(); // edit: clamp to max
                return false;                   // edit: ding overflow
            }
            if (tmp < lo) {
                out = numeric_limits<T>::lowest(); // edit: clamp to lowest
                return false;                      // edit: ding underflow
            }

            result = static_cast<T>(tmp);
        }
    }

    out = result;     // edit: set out param with final result
    return true;      // edit: success (no saturation performed)
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>


template <typename T>
bool subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, T& out)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        if constexpr (numeric_limits<T>::is_integer) {
            const T maxv = numeric_limits<T>::max();
            const T minv = numeric_limits<T>::lowest();

            if constexpr (is_signed<T>::value) {
                if (decrement > 0 && result < static_cast<T>(minv + decrement)) {
                    out = minv;              // edit: clamp to min on underflow
                    return false;            // edit: ding underflow
                }
                if (decrement < 0 && result > static_cast<T>(maxv + decrement)) {
                    out = maxv;              // edit: clamp to max on overflow
                    return false;            // edit: ding overflow (subtracting a negative adds)
                }
            }
            else {
                // Unsigned: underflow when result < decrement
                if (result < decrement) {
                    out = static_cast<T>(0); // edit: clamp to 0 (unsigned min)
                    return false;            // edit: ding underflow
                }
            }

            result = static_cast<T>(result - decrement); // safe after checks
        }
        else {
            // Floating-point path
            long double tmp = static_cast<long double>(result) - static_cast<long double>(decrement);
            const long double hi = static_cast<long double>(numeric_limits<T>::max());
            const long double lo = static_cast<long double>(numeric_limits<T>::lowest());

            if (!isfinite(tmp) || tmp > hi) {
                out = numeric_limits<T>::max(); // edit: clamp to max
                return false;                   // edit: ding overflow
            }
            if (tmp < lo) {
                out = numeric_limits<T>::lowest(); // edit: clamp to lowest
                return false;                      // edit: ding underflow
            }

            result = static_cast<T>(tmp);
        }
    }

    out = result;     // edit: set out param with final result
    return true;      // edit: success (no saturation performed)
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    const unsigned long int steps = 5;
    const T increment = numeric_limits<T>::max() / steps;
    const T start = 0;

    cout << "Overflow Test of Type = " << typeid(T).name() << endl;
    // END DO NOT CHANGE

    cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    // edit: (bool + out parameter)
    T result{};
    bool okAdd = add_numbers<T>(start, increment, steps, result);  // edit: capture status
    cout << +result << " | overflow=" << boolalpha << (!okAdd) << endl; // edit: print status

    cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    okAdd = add_numbers<T>(start, increment, steps + 1, result);   // edit: capture status
    cout << +result << " | overflow=" << boolalpha << (!okAdd) << endl; // edit: print status
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    const unsigned long int steps = 5;
    const T decrement = numeric_limits<T>::max() / steps;
    const T start = numeric_limits<T>::max();

    cout << "Underflow Test of Type = " << typeid(T).name() << endl;
    // END DO NOT CHANGE

    cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    T result{};
    bool okSub = subtract_numbers<T>(start, decrement, steps, result);
    cout << +result << " | overflow=" << boolalpha << (!okSub) << endl;

    cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    okSub = subtract_numbers<T>(start, decrement, steps + 1, result);
    cout << +result << " | overflow=" << boolalpha << (!okSub) << endl;
}

void do_overflow_tests(const string& star_line)
{
    cout << endl << star_line << endl;
    cout << "*** Running Overflow Tests ***" << endl;
    cout << star_line << endl;

    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const string& star_line)
{
    cout << endl << star_line << endl;
    cout << "*** Running Undeflow Tests ***" << endl;
    cout << star_line << endl;

    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    const string star_line = string(50, '*');

    cout << "Starting Numeric Underflow / Overflow Tests!" << endl;

    do_overflow_tests(star_line);
    do_underflow_tests(star_line);

    cout << endl << "All Numeric Underflow / Overflow Tests Complete!" << endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
